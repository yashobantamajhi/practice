package org.custom.connector.jdbc.client;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

public class APIClient {
  private static final Logger LOGGER = LoggerFactory.getLogger(APIClient.class);
  private final String apiEndpoint;
  private final String apiKey;
  private final String secretKey;
  private final HttpClient httpClient;
  private final ObjectMapper objectMapper;

  public APIClient(Map<String, String> credentials) {
    this.apiEndpoint = credentials.get("apiEndpoint");
    this.apiKey = credentials.get("apiKey");
    this.secretKey = credentials.get("secretKey");
    this.httpClient = HttpClients.createDefault();
    this.objectMapper = new ObjectMapper();
  }

  public JsonNode fetchData(String path) throws IOException {
    String url = apiEndpoint + path;
    HttpGet request = new HttpGet(url);

    // Add authentication headers
    request.addHeader("X-API-Key", apiKey);
    if (secretKey != null && !secretKey.isEmpty()) {
      request.addHeader("X-Secret-Key", secretKey);
    }

    LOGGER.info("Making API request to: {}", url);

    try {
      HttpResponse response = httpClient.execute(request);
      String responseBody = EntityUtils.toString(response.getEntity());

      int statusCode = response.getStatusLine().getStatusCode();
      if (statusCode >= 200 && statusCode < 300) {
        return objectMapper.readTree(responseBody);
      } else {
        LOGGER.error("API request failed with status code: {} and response: {}", statusCode, responseBody);
        throw new IOException("API request failed with status code: " + statusCode);
      }
    } catch (Exception e) {
      LOGGER.error("Error making API request: {}", e.getMessage());
      throw e;
    }
  }
}