// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.handler;

import com.amazonaws.appflow.custom.connector.handlers.MetadataHandler;
import com.amazonaws.appflow.custom.connector.model.ErrorCode;
import com.amazonaws.appflow.custom.connector.model.ImmutableErrorDetails;
import com.amazonaws.appflow.custom.connector.model.metadata.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class APIConnectorMetadataHandler implements MetadataHandler {
  private static final Logger LOGGER = LoggerFactory.getLogger(APIConnectorMetadataHandler.class);

  @Override
  public ListEntitiesResponse listEntities(ListEntitiesRequest request) {
    try {

      List<Entity> entities = new ArrayList<>();
      // Parse the response and create entities
      // This is an example - adjust according to your API response structure

        entities.add(ImmutableEntity.builder()
          .entityIdentifier("name")
          .label("label")
          .hasNestedEntities(false)
          .build());


      return ImmutableListEntitiesResponse.builder()
        .isSuccess(true)
        .entities(entities)
        .build();
    } catch (Exception e) {
      LOGGER.error("Error listing entities: {}", e.getMessage());
      return ImmutableListEntitiesResponse.builder()
        .isSuccess(false)
        .errorDetails(ImmutableErrorDetails.builder()
          .errorCode(ErrorCode.InvalidCredentials)
          .errorMessage(e.getMessage())
          .build())
        .build();
    }
  }

  @Override
  public DescribeEntityResponse describeEntity(DescribeEntityRequest request) {
    try {


      List<FieldDefinition> fields = new ArrayList<>();
      // Parse the response and create field definitions
      // This is an example - adjust according to your API response structure

        fields.add(ImmutableFieldDefinition.builder()
          .fieldName("name")
          .dataType(FieldDataType.String)
          .dataTypeLabel("type")
          .label("label")
          .isPrimaryKey(false)
          .build());


      return ImmutableDescribeEntityResponse.builder()
        .isSuccess(true)
        .entityDefinition(ImmutableEntityDefinition.builder()
          .fields(fields)
          .build())
        .build();
    } catch (Exception e) {
      LOGGER.error("Error describing entity: {}", e.getMessage());
      return ImmutableDescribeEntityResponse.builder()
        .isSuccess(false)
        .errorDetails(ImmutableErrorDetails.builder()
          .errorCode(ErrorCode.InvalidCredentials)
          .errorMessage(e.getMessage())
          .build())
        .build();
    }
  }


}
