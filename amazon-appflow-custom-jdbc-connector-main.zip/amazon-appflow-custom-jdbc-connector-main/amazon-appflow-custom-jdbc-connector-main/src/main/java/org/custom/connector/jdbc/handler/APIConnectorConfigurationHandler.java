// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.handler;

import com.amazonaws.appflow.custom.connector.handlers.ConfigurationHandler;
import com.amazonaws.appflow.custom.connector.model.ErrorCode;
import com.amazonaws.appflow.custom.connector.model.ImmutableErrorDetails;
import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.DescribeConnectorConfigurationRequest;
import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.DescribeConnectorConfigurationResponse;
import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.ImmutableDescribeConnectorConfigurationResponse;
import com.amazonaws.appflow.custom.connector.model.credentials.ImmutableValidateCredentialsResponse;
import com.amazonaws.appflow.custom.connector.model.credentials.ValidateCredentialsRequest;
import com.amazonaws.appflow.custom.connector.model.credentials.ValidateCredentialsResponse;
import com.amazonaws.appflow.custom.connector.model.settings.ImmutableValidateConnectorRuntimeSettingsResponse;
import com.amazonaws.appflow.custom.connector.model.settings.ValidateConnectorRuntimeSettingsRequest;
import com.amazonaws.appflow.custom.connector.model.settings.ValidateConnectorRuntimeSettingsResponse;
import org.custom.connector.jdbc.config.APIConnectorConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class APIConnectorConfigurationHandler implements ConfigurationHandler {
  private static final Logger LOGGER = LoggerFactory.getLogger(APIConnectorConfigurationHandler.class);
  private static final String CONNECTOR_OWNER = "example";
  private static final String CONNECTOR_NAME = "APIConnector";
  private static final String CONNECTOR_VERSION = "1.0";

  @Override
  public ValidateConnectorRuntimeSettingsResponse validateConnectorRuntimeSettings(
    ValidateConnectorRuntimeSettingsRequest request) {
    return ImmutableValidateConnectorRuntimeSettingsResponse.builder()
      .isSuccess(true)
      .build();
  }

  @Override
  public ValidateCredentialsResponse validateCredentials(ValidateCredentialsRequest request) {
    try {
      // Add validation logic here if needed
      return ImmutableValidateCredentialsResponse.builder()
        .isSuccess(true)
        .build();
    } catch (Exception e) {
      LOGGER.error("Failed to validate credentials: {}", e.getMessage());
      return ImmutableValidateCredentialsResponse.builder()
        .isSuccess(false)
        .errorDetails(ImmutableErrorDetails.builder()
          .errorCode(ErrorCode.InvalidCredentials)
          .errorMessage(e.getMessage())
          .build())
        .build();
    }
  }

  @Override
  public DescribeConnectorConfigurationResponse describeConnectorConfiguration(
    DescribeConnectorConfigurationRequest request) {
    return ImmutableDescribeConnectorConfigurationResponse.builder()
      .isSuccess(true)
      .connectorOwner(CONNECTOR_OWNER)
      .connectorName(CONNECTOR_NAME)
      .connectorVersion(CONNECTOR_VERSION)
      .connectorModes(APIConnectorConfiguration.getConnectorModes())
      .connectorRuntimeSetting(APIConnectorConfiguration.getConnectorRuntimeSettings())
      .authenticationConfig(APIConnectorConfiguration.getAuthenticationConfig())
      .supportedApiVersions(APIConnectorConfiguration.getSupportedApiVersions())
      .build();
  }
}
