// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.handler;

import com.amazonaws.appflow.custom.connector.lambda.handler.BaseLambdaConnectorHandler;

public class APIConnectorLambdaHandler extends BaseLambdaConnectorHandler {

  public APIConnectorLambdaHandler() {
    super(
      new APIConnectorMetadataHandler(),
      new APIConnectorRecordHandler(),
      new APIConnectorConfigurationHandler()
    );
  }
}
