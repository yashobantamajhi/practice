// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.config;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.ConnectorModes;
import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.auth.*;
import com.amazonaws.appflow.custom.connector.model.settings.ConnectorRuntimeSetting;
import com.amazonaws.appflow.custom.connector.model.settings.ConnectorRuntimeSettingDataType;
import com.amazonaws.appflow.custom.connector.model.settings.ConnectorRuntimeSettingScope;
import com.amazonaws.appflow.custom.connector.model.settings.ImmutableConnectorRuntimeSetting;

public final class APIConnectorConfiguration {
  private APIConnectorConfiguration() {
  }

  public static List<ConnectorRuntimeSetting> getConnectorRuntimeSettings() {
    ConnectorRuntimeSetting apiEndpoint = ImmutableConnectorRuntimeSetting.builder()
      .key("apiEndpoint")
      .dataType(ConnectorRuntimeSettingDataType.String)
      .required(true)
      .label("API Endpoint")
      .description("The base URL of the API endpoint")
      .scope(ConnectorRuntimeSettingScope.CONNECTOR_PROFILE)
      .build();

    return Collections.singletonList(apiEndpoint);
  }

  public static List<ConnectorModes> getConnectorModes() {
    return Arrays.asList(ConnectorModes.SOURCE);
  }

  public static List<String> getSupportedApiVersions() {
    return Collections.singletonList("v1");
  }

  public static AuthenticationConfig getAuthenticationConfig() {
    AuthParameter apiKey = ImmutableAuthParameter.builder()
      .key("apiKey")
      .label("API Key")
      .description("API Key for authentication")
      .required(true)
      .sensitiveField(true)
      .build();

    AuthParameter secretKey = ImmutableAuthParameter.builder()
      .key("secretKey")
      .label("Secret Key")
      .description("Secret Key for authentication (if required)")
      .required(false)
      .sensitiveField(true)
      .build();

    return ImmutableAuthenticationConfig.builder()
      .isCustomAuthSupported(true)
      .addCustomAuthConfig(
        ImmutableCustomAuthConfig.builder()
          .authenticationType("API_KEY")
          .addAuthParameters(apiKey, secretKey)
          .build())
      .build();
  }
}
