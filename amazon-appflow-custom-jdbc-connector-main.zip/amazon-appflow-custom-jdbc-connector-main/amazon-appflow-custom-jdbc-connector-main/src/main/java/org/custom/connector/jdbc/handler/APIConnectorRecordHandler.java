package org.custom.connector.jdbc.handler;

import com.amazonaws.appflow.custom.connector.handlers.RecordHandler;
import com.amazonaws.appflow.custom.connector.model.ErrorCode;
import com.amazonaws.appflow.custom.connector.model.ImmutableErrorDetails;
import com.amazonaws.appflow.custom.connector.model.metadata.FieldDefinition;

import com.amazonaws.appflow.custom.connector.model.query.ImmutableQueryDataResponse;
import com.amazonaws.appflow.custom.connector.model.query.QueryDataRequest;
import com.amazonaws.appflow.custom.connector.model.query.QueryDataResponse;
import com.amazonaws.appflow.custom.connector.model.retreive.ImmutableRetrieveDataResponse;
import com.amazonaws.appflow.custom.connector.model.retreive.RetrieveDataRequest;
import com.amazonaws.appflow.custom.connector.model.retreive.RetrieveDataResponse;
import com.amazonaws.appflow.custom.connector.model.write.ImmutableWriteDataResponse;
import com.amazonaws.appflow.custom.connector.model.write.WriteDataRequest;
import com.amazonaws.appflow.custom.connector.model.write.WriteDataResponse;
import com.fasterxml.jackson.databind.JsonNode;
import org.custom.connector.jdbc.client.APIClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class APIConnectorRecordHandler implements RecordHandler {
  private static final Logger LOGGER = LoggerFactory.getLogger(APIConnectorRecordHandler.class);

  @Override
  public RetrieveDataResponse retrieveData(RetrieveDataRequest request) {
    try {


      return ImmutableRetrieveDataResponse.builder()
        .isSuccess(true)
        .records(null)
        .build();
    } catch (Exception e) {
      LOGGER.error("Error retrieving data: {}", e.getMessage());
      return ImmutableRetrieveDataResponse.builder()
        .isSuccess(false)
        .errorDetails(ImmutableErrorDetails.builder()
          .errorCode(ErrorCode.InvalidCredentials)
          .errorMessage(e.getMessage())
          .build())
        .build();
    }
  }

  private String convertJsonNodeToString(JsonNode node) {
    if (node.isNull()) {
      return null;
    } else if (node.isTextual()) {
      return node.asText();
    } else {
      return node.toString();
    }
  }

  @Override
  public WriteDataResponse writeData(WriteDataRequest request) {
    // This connector is read-only
    return ImmutableWriteDataResponse.builder()
      .isSuccess(false)
      .errorDetails(ImmutableErrorDetails.builder()
        .errorCode(null)
        .errorMessage("Write operation is not supported")
        .build())
      .build();
  }

  @Override
  public QueryDataResponse queryData(QueryDataRequest queryDataRequest) {
    return ImmutableQueryDataResponse.builder().errorDetails(null).isSuccess(true).build();
  }
}