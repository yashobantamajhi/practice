// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.handler;

import com.amazonaws.appflow.custom.connector.handlers.RecordHandler;
import com.amazonaws.appflow.custom.connector.model.ErrorCode;
import com.amazonaws.appflow.custom.connector.model.ErrorDetails;
import com.amazonaws.appflow.custom.connector.model.ImmutableErrorDetails;
import com.amazonaws.appflow.custom.connector.model.query.ImmutableQueryDataResponse;
import com.amazonaws.appflow.custom.connector.model.query.QueryDataRequest;
import com.amazonaws.appflow.custom.connector.model.query.QueryDataResponse;
import com.amazonaws.appflow.custom.connector.model.retreive.ImmutableRetrieveDataResponse;
import com.amazonaws.appflow.custom.connector.model.retreive.RetrieveDataRequest;
import com.amazonaws.appflow.custom.connector.model.retreive.RetrieveDataResponse;
import com.amazonaws.appflow.custom.connector.model.write.ImmutableWriteDataResponse;
import com.amazonaws.appflow.custom.connector.model.write.WriteDataRequest;
import com.amazonaws.appflow.custom.connector.model.write.WriteDataResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.custom.connector.jdbc.config.Phone;
import org.custom.connector.jdbc.validation.JDBCRequestValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public final class JDBCConnectorRecordHandler implements RecordHandler {
  final ObjectMapper objectMapper = new ObjectMapper();
  private final Logger logger = LoggerFactory.getLogger(JDBCConnectorRecordHandler.class);

  /**
   * Retrieves the batch of records against a set of identifiers from the source application
   * Not used at the moment.
   *
   * @param request - {@link RetrieveDataRequest}
   * @return - {@link RetrieveDataResponse}
   */
  @Override
  public RetrieveDataResponse retrieveData(final RetrieveDataRequest request) {
    System.out.println("retrieveData called ");
    logger.error("retrieveData request failed with errorDetails ");
    ErrorDetails errorDetails = JDBCRequestValidator.validateRetrieveDataRequest(request);
    if (Objects.nonNull(errorDetails)) {
      logger.error("RetrieveData request failed with errorDetails " + errorDetails);
      return ImmutableRetrieveDataResponse.builder().isSuccess(false).errorDetails(errorDetails).build();
    }
    return null;
  }

  /**
   * Writes batch of records to the destination application
   *
   * @param request - {@link WriteDataRequest}
   * @return - {@link WriteDataResponse}
   */
  @Override
  public WriteDataResponse writeData(final WriteDataRequest request) {
    System.out.println("writeData called ");
    ErrorDetails errorDetails = JDBCRequestValidator.validateWriteDataRequest(request);
    if (Objects.nonNull(errorDetails)) {
      logger.error("WriteData request failed with errorDetails " + errorDetails);
      return ImmutableWriteDataResponse.builder().isSuccess(false).errorDetails(errorDetails).build();
    }
    try {
      System.out.println("writeData process ");
      return ImmutableWriteDataResponse.builder()
        .isSuccess(true)
        .build();
    } catch (Exception ex) {
      logger.error("Exception: " + ex.getMessage());
      return ImmutableWriteDataResponse.builder()
        .isSuccess(false)
        .errorDetails(ImmutableErrorDetails.builder()
          .errorCode(ErrorCode.ClientError)
          .errorMessage(ex.getMessage())
          .build())
        .build();
    }
  }

  /**
   * Queries the data from the source application against the supplied filter conditions.
   *
   * @param request - {@link QueryDataRequest}
   * @return - {@link QueryDataResponse}
   */
  @Override
  public QueryDataResponse queryData(final QueryDataRequest request) {

    System.out.println("QueryData called ");
    ErrorDetails errorDetails = JDBCRequestValidator.validateQueryDataRequest(request);
    if (Objects.nonNull(errorDetails)) {
      logger.error("QueryData request failed with errorDetails " + errorDetails);
      return ImmutableQueryDataResponse.builder().errorDetails(errorDetails).isSuccess(false).build();
    }

    try {
      OkHttpClient client = new OkHttpClient().newBuilder()
        .build();
      List<String> records = new ArrayList<>();
      String nextToken = request.nextToken();
      System.out.println("next token " + nextToken);
      Request req = new Request.Builder()
        .url("https://api.restful-api.dev/objects")
        .build();
      Response response = client.newCall(req).execute();
      System.out.println("api called ");
      if (response.isSuccessful()) {
        String responseBody = response.body().string();

        ObjectMapper mapper = new ObjectMapper();

        List<Phone> products = mapper.readValue(responseBody, new TypeReference<List<Phone>>() {
        });


        List<String> names = products.stream()
          .map(Phone::getName)
          .collect(Collectors.toList());
        List<ObjectNode> jsonList = new ArrayList<>();
        for (String name : names) {
          ObjectNode obj = mapper.createObjectNode();
          obj.put("name", name);
          jsonList.add(obj);
          String jsonOutput = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(obj);
          records.add(jsonOutput);
        }

        System.out.println("Data from JSON: " + records);
      }


      System.out.println("api call ended ");
      return ImmutableQueryDataResponse.builder()
        .records(records)
        .nextToken(nextToken)
        .isSuccess(true)
        .build();
    } catch (Exception ex) {
      System.out.println("Exception!!!!!!!!!!! ");
      logger.error("Exception: " + ex.getMessage());

      return ImmutableQueryDataResponse.builder()
        .errorDetails(
          ImmutableErrorDetails.builder()
            .errorCode(ErrorCode.ClientError)
            .errorMessage(ex.getMessage())
            .build()
        ).isSuccess(false).build();
    }
  }
}
