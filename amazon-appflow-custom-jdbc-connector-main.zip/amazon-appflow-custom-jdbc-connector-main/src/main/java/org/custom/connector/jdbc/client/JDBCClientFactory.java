// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.client;

import java.util.Map;

import com.amazonaws.appflow.custom.connector.model.credentials.Credentials;

public class JDBCClientFactory implements AbstractFactory<JDBCClient> {

  @Override
  public JDBCClient create(final Credentials creds) {
    System.out.println("Secret ARN  : " + creds.secretArn());
    Map<String, String> secrets = SecretsManagerHelper.getSecret(creds.secretArn());
    String driver = secrets.getOrDefault("driver", null);
    System.out.println("Driver  : " + driver);

    secrets.forEach((k, v) -> System.out.println("key: " + k + " value:" + v));
    return new MySQLClient(secrets);

  }
}
