// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.client;

import com.amazonaws.appflow.custom.connector.model.query.QueryDataRequest;
import com.amazonaws.appflow.custom.connector.model.write.WriteDataRequest;
import com.amazonaws.appflow.custom.connector.model.write.WriteOperationType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



import java.util.ArrayList;

import java.util.List;
import java.util.Map;


public final class MySQLClient implements JDBCClient {
  private static final Logger LOGGER = LoggerFactory.getLogger(MySQLClient.class);

  private final Map<String, String> credentials;

  public MySQLClient(final Map<String, String> creds) {
    credentials = creds;
  }

  @Override
  public List<WriteOperationType> getWriteOperations() {
    List<WriteOperationType> writeOperationTypes = new ArrayList<>();
    writeOperationTypes.add(WriteOperationType.UPSERT);
    writeOperationTypes.add(WriteOperationType.UPDATE);
    writeOperationTypes.add(WriteOperationType.INSERT);
    return writeOperationTypes;
  }


  @Override
  public List<String> queryData(final QueryDataRequest request) {
    List<String> records = new ArrayList<String>();

    return records;
  }

  @Override
  public int[] writeData(final WriteDataRequest request) {

    return new int[0];
  }


}
