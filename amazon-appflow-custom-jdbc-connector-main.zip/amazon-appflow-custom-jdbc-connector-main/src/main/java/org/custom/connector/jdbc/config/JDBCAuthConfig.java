// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: MIT-0

package org.custom.connector.jdbc.config;

import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.auth.AuthParameter;
import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.auth.CustomAuthConfig;
import com.amazonaws.appflow.custom.connector.model.connectorconfiguration.auth.ImmutableAuthParameter;

import java.util.Arrays;
import java.util.List;

public class JDBCAuthConfig implements CustomAuthConfig {

  @Override
  public String authenticationType() {
    return "JDBC";
  }

  @Override
  public List<AuthParameter> authParameters() {
    AuthParameter driver = ImmutableAuthParameter.builder()
      .key("api")
      .label("API")
      .description("Database driver")
      .addConnectorSuppliedValues("apiEndpoint")
      .required(true)
      .sensitiveField(false)
      .build();

    AuthParameter hostname = ImmutableAuthParameter.builder()
      .key("url")
      .label("url")
      .description("Database hostname - must be reachable")
      .required(true)
      .sensitiveField(false)
      .build();


    return Arrays.asList(driver, hostname);
  }
}
